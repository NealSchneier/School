#include "uthreads.h"
#include "list.h"

void uthreads_mutex_init(uthreads_mutex_t m)
{
    /* your implementation goes here. */
}

void uthreads_mutex_lock(uthreads_mutex_t m)
{
    /* your implementation goes here. */
}

void uthreads_mutex_unlock(uthreads_mutex_t m)
{
    /* your implementation goes here. */
}
