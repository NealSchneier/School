/* term.h -- definition of term structure ($Revision: 1.1.1.1 $) */

struct Term {
	char *str;
	Closure *closure;
};
