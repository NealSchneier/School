#!/usr/bin/python


# the shell executable.
shell = "./esh -pplugins"

# the prompt printed by your shell
prompt = "esh> "

# the output when setting a variable
variable_set = "([A-Za-z0-9_$-]+)\s*=\s*\"([A-Za-z0-9_$-]+)\"";