#!/usr/bin/python


# the shell executable.
shell = "./esh"

# the prompt printed by your shell
prompt = "esh> "
